from setuptools import setup

setup(
  
    name = "paquetecalculos",
    version="1.0",
    descripcion = "paquete de redondeo y potencia",
    author = "rohe",
    author_email = "rohermy.ochoa@gmail.com",
    url = "https://www.github.com/RoheOo",
    packages = [ "calculos","calculos.redondeo_potencia" ]

)